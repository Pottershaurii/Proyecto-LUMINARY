-- 1. Insertar datos en la tabla Institucion
INSERT INTO Institucion (InstitucionID, Nombre, Direccion, Telefono) VALUES
(1, 'Universidad Nacional Aut�noma', 'Av. Universidad 3000, CDMX', '55-5622-1234'),
(2, 'Instituto Tecnol�gico Superior', 'Calle Tecnolog�a 123, Guadalajara', '33-3915-6789'),
(3, 'Universidad Aut�noma Metropolitana', 'Av. San Pablo 180, CDMX', '55-5318-9000'),
(4, 'Universidad de Guadalajara', 'Av. Ju�rez 976, Guadalajara', '33-3134-2222');

-- 2. Insertar datos en la tabla Facultad
INSERT INTO Facultad (FacultadID, InstitucionID, Nombre) VALUES
(1, 1, 'Facultad de Ciencias'),
(2, 1, 'Facultad de Ingenier�a'),
(3, 2, 'Facultad de Sistemas Computacionales'),
(4, 3, 'Facultad de Ciencias Sociales y Humanidades'),
(5, 4, 'Facultad de Medicina');

-- 3. Insertar datos en la tabla Departamento
INSERT INTO Departamento (DepartamentoID, FacultadID, Nombre) VALUES
(1, 1, 'Departamento de F�sica'),
(2, 2, 'Departamento de Ingenier�a El�ctrica'),
(3, 3, 'Departamento de Inteligencia Artificial'),
(4, 4, 'Departamento de Sociolog�a'),
(5, 5, 'Departamento de Ciencias Biom�dicas');

-- 4. Insertar datos en la tabla Evento
INSERT INTO Evento (EventoID, Nombre, Fecha, Hora, Lugar, TipoEvento, DepartamentoID) VALUES
(1, 'Simposio de F�sica Cu�ntica', '2024-11-15', '09:00:00', 'Auditorio Principal', 'Simposio', 1),
(2, 'Conferencia de Energ�as Renovables', '2024-10-20', '14:00:00', 'Sala de Conferencias A', 'Conferencia', 2),
(3, 'Workshop de Machine Learning', '2024-09-05', '10:00:00', 'Laboratorio de C�mputo', 'Workshop', 3),
(4, 'Congreso de Sociolog�a Latinoamericana', '2024-12-01', '08:00:00', 'Centro de Convenciones', 'Congreso', 4),
(5, 'Jornadas de Investigaci�n Biom�dica', '2025-02-10', '11:00:00', 'Hospital Universitario', 'Jornadas', 5);

-- 5. Insertar datos en la tabla Seminario
INSERT INTO Seminario (SeminarioID, EventoID, Tema, Duracion) VALUES
(1, 1, 'Fundamentos de la F�sica Cu�ntica', 120),
(2, 2, 'Implementaci�n de Paneles Solares en Zonas Urbanas', 90),
(3, 3, 'Introducci�n a Redes Neuronales', 180),
(4, 4, 'Movimientos Sociales en Am�rica Latina', 150),
(5, 5, 'Avances en Terapia G�nica', 120);

-- 6. Insertar datos en la tabla Ponente
INSERT INTO Ponente (PonenteID, Nombre, Apellido, Especialidad, Email) VALUES
(1, 'Mar�a', 'Gonz�lez', 'F�sica Cu�ntica', 'maria.gonzalez@email.com'),
(2, 'Carlos', 'Rodr�guez', 'Energ�as Renovables', 'carlos.rodriguez@email.com'),
(3, 'Ana', 'Mart�nez', 'Inteligencia Artificial', 'ana.martinez@email.com'),
(4, 'Jorge', 'S�nchez', 'Sociolog�a', 'jorge.sanchez@email.com'),
(5, 'Laura', 'Ram�rez', 'Biomedicina', 'laura.ramirez@email.com');

-- 7. Insertar datos en la tabla Ponente_Seminario
INSERT INTO Ponente_Seminario (PonenteID, SeminarioID) VALUES
(1, 1), (2, 2), (3, 3), (4, 4), (5, 5);

-- 8. Insertar datos en la tabla Asistente
INSERT INTO Asistente (AsistenteID, Nombre, Apellido, Email, Telefono) VALUES
(1, 'Juan', 'P�rez', 'juan.perez@email.com', '55-1234-5678'),
(2, 'Laura', 'S�nchez', 'laura.sanchez@email.com', '33-9876-5432'),
(3, 'Pedro', 'Ram�rez', 'pedro.ramirez@email.com', '81-2468-1357'),
(4, 'Sof�a', 'Hern�ndez', 'sofia.hernandez@email.com', '55-3698-1470'),
(5, 'Miguel', 'Torres', 'miguel.torres@email.com', '33-7412-9630');

-- 9. Insertar datos en la tabla Inscripcion
INSERT INTO Inscripcion (InscripcionID, AsistenteID, EventoID, FechaInscripcion) VALUES
(1, 1, 1, '2024-10-01'), (2, 2, 2, '2024-09-15'), (3, 3, 3, '2024-08-20'),
(4, 4, 4, '2024-11-10'), (5, 5, 5, '2025-01-15');

-- 10. Insertar datos en la tabla Pago
INSERT INTO Pago (PagoID, InscripcionID, Monto, FechaPago, MetodoPago) VALUES
(1, 1, 500.00, '2024-10-02', 'Tarjeta de Cr�dito'),
(2, 2, 350.00, '2024-09-16', 'Transferencia Bancaria'),
(3, 3, 750.00, '2024-08-21', 'PayPal'),
(4, 4, 1000.00, '2024-11-11', 'Tarjeta de D�bito'),
(5, 5, 600.00, '2025-01-16', 'Efectivo');

-- 11. Insertar datos en la tabla Sala
INSERT INTO Sala (SalaID, Nombre, Capacidad, Ubicacion) VALUES
(1, 'Auditorio Principal', 500, 'Edificio A, Planta Baja'),
(2, 'Sala de Conferencias A', 100, 'Edificio B, Segundo Piso'),
(3, 'Laboratorio de C�mputo', 50, 'Edificio C, Tercer Piso'),
(4, 'Centro de Convenciones', 1000, 'Av. Principal 123'),
(5, 'Sal�n Magna', 200, 'Edificio D, Primer Piso');

-- 12. Insertar datos en la tabla Evento_Sala
INSERT INTO Evento_Sala (EventoID, SalaID) VALUES
(1, 1), (2, 2), (3, 3), (4, 4), (5, 5);

-- 13. Insertar datos en la tabla Patrocinador
INSERT INTO Patrocinador (PatrocinadorID, Nombre, Tipo, ContactoNombre, ContactoEmail) VALUES
(1, 'TechCorp', 'Empresa Tecnol�gica', 'Ana L�pez', 'ana.lopez@techcorp.com'),
(2, 'EcoSolutions', 'ONG Ambiental', 'Luis Mart�nez', 'luis.martinez@ecosolutions.org'),
(3, 'DataMinds', 'Empresa de Software', 'Carmen Ruiz', 'carmen.ruiz@dataminds.com'),
(4, 'Fundaci�nEducar', 'Fundaci�n Educativa', 'Roberto G�mez', 'roberto.gomez@educar.org'),
(5, 'BioTech Labs', 'Laboratorio Farmac�utico', 'Elena Vargas', 'elena.vargas@biotechlabs.com');

-- 14. Insertar datos en la tabla Patrocinio
INSERT INTO Patrocinio (PatrocinioID, EventoID, PatrocinadorID, MontoPatrocinio) VALUES
(1, 1, 1, 10000.00), (2, 2, 2, 7500.00), (3, 3, 3, 15000.00),
(4, 4, 4, 12000.00), (5, 5, 5, 20000.00);

-- 15. Insertar datos en la tabla Feedback
INSERT INTO Feedback (FeedbackID, EventoID, AsistenteID, Puntuacion, Comentario, FechaFeedback) VALUES
(1, 1, 1, 5, 'Excelente simposio, muy informativo', '2024-11-16'),
(2, 2, 2, 4, 'Buena conferencia, pero falt� tiempo para preguntas', '2024-10-21'),
(3, 3, 3, 5, 'Workshop muy pr�ctico y �til', '2024-09-06'),
(4, 4, 4, 4, 'Congreso interesante, buenos ponentes', '2024-12-03'),
(5, 5, 5, 5, 'Jornadas muy bien organizadas y contenido de calidad', '2025-02-12');

-- 16. Insertar datos en la tabla Material
INSERT INTO Material (MaterialID, EventoID, Nombre, Tipo, URL) VALUES
(1, 1, 'Presentaci�n F�sica Cu�ntica', 'PDF', 'https://evento.com/materiales/fisica_cuantica.pdf'),
(2, 2, 'Gu�a Energ�as Renovables', 'DOC', 'https://evento.com/materiales/guia_energias.doc'),
(3, 3, 'C�digo Fuente Redes Neuronales', 'ZIP', 'https://evento.com/materiales/codigo_redes.zip'),
(4, 4, 'Res�menes Congreso Sociolog�a', 'PDF', 'https://evento.com/materiales/resumenes_sociologia.pdf'),
(5, 5, 'P�sters Investigaci�n Biom�dica', 'JPG', 'https://evento.com/materiales/posters_biomedica.jpg');

-- 17. Insertar datos en la tabla Comite
INSERT INTO Comite (ComiteID, EventoID, Nombre) VALUES
(1, 1, 'Comit� Cient�fico de F�sica'),
(2, 2, 'Comit� Organizador de Energ�as Renovables'),
(3, 3, 'Comit� T�cnico de IA'),
(4, 4, 'Comit� Acad�mico de Sociolog�a'),
(5, 5, 'Comit� de �tica en Investigaci�n Biom�dica');

-- 18. Insertar datos en la tabla Miembro_Comite
INSERT INTO Miembro_Comite (MiembroID, ComiteID, Nombre, Apellido, Email, Rol) VALUES
(1, 1, 'Ricardo', 'Fern�ndez', 'ricardo.fernandez@email.com', 'Presidente'),
(2, 2, 'Alejandra', 'Guti�rrez', 'alejandra.gutierrez@email.com', 'Secretaria'),
(3, 3, 'Fernando', 'D�az', 'fernando.diaz@email.com', 'Coordinador T�cnico'),
(4, 4, 'Gabriela', 'Vega', 'gabriela.vega@email.com', 'Vocal'),
(5, 5, 'H�ctor', 'Morales', 'hector.morales@email.com', 'Director de �tica');

-- 19. Insertar datos en la tabla Presupuesto
INSERT INTO Presupuesto (PresupuestoID, EventoID, MontoTotal, FechaAprobacion) VALUES
(1, 1, 50000.00, '2024-08-01'),
(2, 2, 35000.00, '2024-07-15'),
(3, 3, 70000.00, '2024-06-20'),
(4, 4, 100000.00, '2024-09-01'),
(5, 5, 80000.00, '2024-11-15');

-- 20. Insertar datos en la tabla Gasto
INSERT INTO Gasto (GastoID, EventoID, Concepto, Monto, FechaGasto) VALUES
(1, 1, 'Alquiler de Equipo Audiovisual', 5000.00, '2024-11-10'),
(2, 2, 'Catering', 3000.00, '2024-10-19'),
(3, 3, 'Material Impreso', 2000.00, '2024-09-01'),
(4, 4, 'Transporte de Ponentes', 10000.00, '2024-11-30'),
(5, 5, 'Alquiler de Stands', 8000.00, '2025-02-05');