Create database Eventos_Academicos 

-- 1. Tabla de Instituciones Educativas
CREATE TABLE Institucion (
    InstitucionID INT PRIMARY KEY,
    Nombre VARCHAR(100),
    Direccion VARCHAR(200),
    Telefono VARCHAR(20)
);

-- 2. Tabla de Facultades
CREATE TABLE Facultad (
    FacultadID INT PRIMARY KEY,
    InstitucionID INT,
    Nombre VARCHAR(100),
    FOREIGN KEY (InstitucionID) REFERENCES Institucion(InstitucionID)
);

-- 3. Tabla de Departamentos
CREATE TABLE Departamento (
    DepartamentoID INT PRIMARY KEY,
    FacultadID INT,
    Nombre VARCHAR(100),
    FOREIGN KEY (FacultadID) REFERENCES Facultad(FacultadID)
);

-- 4. Tabla de Eventos
CREATE TABLE Evento (
    EventoID INT PRIMARY KEY,
    Nombre VARCHAR(200),
    Fecha DATE,
    Hora TIME,
    Lugar VARCHAR(200),
    TipoEvento VARCHAR(50),
    DepartamentoID INT,
    FOREIGN KEY (DepartamentoID) REFERENCES Departamento(DepartamentoID)
);

-- 5. Tabla de Seminarios
CREATE TABLE Seminario (
    SeminarioID INT PRIMARY KEY,
    EventoID INT,
    Tema VARCHAR(200),
    Duracion INT, -- en minutos
    FOREIGN KEY (EventoID) REFERENCES Evento(EventoID)
);

-- 6. Tabla de Ponentes
CREATE TABLE Ponente (
    PonenteID INT PRIMARY KEY,
    Nombre VARCHAR(100),
    Apellido VARCHAR(100),
    Especialidad VARCHAR(100),
    Email VARCHAR(100)
);

-- 7. Tabla de Ponente_Seminario
CREATE TABLE Ponente_Seminario (
    PonenteID INT,
    SeminarioID INT,
    PRIMARY KEY (PonenteID, SeminarioID),
    FOREIGN KEY (PonenteID) REFERENCES Ponente(PonenteID),
    FOREIGN KEY (SeminarioID) REFERENCES Seminario(SeminarioID)
);

-- 8. Tabla de Asistentes
CREATE TABLE Asistente (
    AsistenteID INT PRIMARY KEY,
    Nombre VARCHAR(100),
    Apellido VARCHAR(100),
    Email VARCHAR(100),
    Telefono VARCHAR(20)
);

-- 9. Tabla de Inscripciones
CREATE TABLE Inscripcion (
    InscripcionID INT PRIMARY KEY,
    AsistenteID INT,
    EventoID INT,
    FechaInscripcion DATE,
    FOREIGN KEY (AsistenteID) REFERENCES Asistente(AsistenteID),
    FOREIGN KEY (EventoID) REFERENCES Evento(EventoID)
);

-- 10. Tabla de Pagos
CREATE TABLE Pago (
    PagoID INT PRIMARY KEY,
    InscripcionID INT,
    Monto DECIMAL(10,2),
    FechaPago DATE,
    MetodoPago VARCHAR(50),
    FOREIGN KEY (InscripcionID) REFERENCES Inscripcion(InscripcionID)
);

-- 11. Tabla de Salas
CREATE TABLE Sala (
    SalaID INT PRIMARY KEY,
    Nombre VARCHAR(100),
    Capacidad INT,
    Ubicacion VARCHAR(200)
);

-- 12. Tabla de Evento_Sala
CREATE TABLE Evento_Sala (
    EventoID INT,
    SalaID INT,
    PRIMARY KEY (EventoID, SalaID),
    FOREIGN KEY (EventoID) REFERENCES Evento(EventoID),
    FOREIGN KEY (SalaID) REFERENCES Sala(SalaID)
);

-- 13. Tabla de Patrocinadores
CREATE TABLE Patrocinador (
    PatrocinadorID INT PRIMARY KEY,
    Nombre VARCHAR(100),
    Tipo VARCHAR(50),
    ContactoNombre VARCHAR(100),
    ContactoEmail VARCHAR(100)
);

-- 14. Tabla de Patrocinios
CREATE TABLE Patrocinio (
    PatrocinioID INT PRIMARY KEY,
    EventoID INT,
    PatrocinadorID INT,
    MontoPatrocinio DECIMAL(10,2),
    FOREIGN KEY (EventoID) REFERENCES Evento(EventoID),
    FOREIGN KEY (PatrocinadorID) REFERENCES Patrocinador(PatrocinadorID)
);

-- 15. Tabla de Feedback
CREATE TABLE Feedback (
    FeedbackID INT PRIMARY KEY,
    EventoID INT,
    AsistenteID INT,
    Puntuacion INT,
    Comentario TEXT,
    FechaFeedback DATE,
    FOREIGN KEY (EventoID) REFERENCES Evento(EventoID),
    FOREIGN KEY (AsistenteID) REFERENCES Asistente(AsistenteID)
);

-- 16. Tabla de Materiales
CREATE TABLE Material (
    MaterialID INT PRIMARY KEY,
    EventoID INT,
    Nombre VARCHAR(100),
    Tipo VARCHAR(50),
    URL VARCHAR(200),
    FOREIGN KEY (EventoID) REFERENCES Evento(EventoID)
);

-- 17. Tabla de Comit�s
CREATE TABLE Comite (
    ComiteID INT PRIMARY KEY,
    EventoID INT,
    Nombre VARCHAR(100),
    FOREIGN KEY (EventoID) REFERENCES Evento(EventoID)
);

-- 18. Tabla de Miembros de Comit�
CREATE TABLE Miembro_Comite (
    MiembroID INT PRIMARY KEY,
    ComiteID INT,
    Nombre VARCHAR(100),
    Apellido VARCHAR(100),
    Email VARCHAR(100),
    Rol VARCHAR(50),
    FOREIGN KEY (ComiteID) REFERENCES Comite(ComiteID)
);

-- 19. Tabla de Presupuesto
CREATE TABLE Presupuesto (
    PresupuestoID INT PRIMARY KEY,
    EventoID INT,
    MontoTotal DECIMAL(10,2),
    FechaAprobacion DATE,
    FOREIGN KEY (EventoID) REFERENCES Evento(EventoID)
);

-- 20. Tabla de Gastos
CREATE TABLE Gasto (
    GastoID INT PRIMARY KEY,
    EventoID INT,
    Concepto VARCHAR(100),
    Monto DECIMAL(10,2),
    FechaGasto DATE,
    FOREIGN KEY (EventoID) REFERENCES Evento(EventoID)
);